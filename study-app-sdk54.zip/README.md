# Study App (SDK 54-ready)

This repository is prepared to run with **Expo SDK 54**.
Follow the steps below to get it running locally and to build APKs.

## Prerequisites
- Node.js >= 20.19.4 (recommend using nvm to manage Node)
- npm (or yarn)
- expo CLI & eas CLI:
  ```bash
  npm install -g expo-cli eas-cli
  ```

## Setup (one-time)
```bash
# unzip (if you downloaded a zip)
cd study-app-sdk54

# clean install
rm -rf node_modules package-lock.json yarn.lock
npm install

# upgrade/install exact compatible native libs:
npx expo install expo@^54.0.0 --fix
npx expo install react-native-gesture-handler react-native-screens react-native-safe-area-context @react-navigation/native @react-navigation/bottom-tabs react-native-reanimated react-native-worklets

# start dev server
expo start
```

## Notes / Troubleshooting
- If you get build issues, delete `node_modules` and lockfile and run `npm install` again.
- For iOS native builds, run `cd ios && pod install` if using prebuild / bare workflow.
- Use `eas build -p android --profile preview` to create an APK on Expo servers.
- If you rely on `expo-file-system` older API, import from `expo-file-system/legacy` as needed.
