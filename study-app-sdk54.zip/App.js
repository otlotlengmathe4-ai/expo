import React, { useState } from 'react';
import { Text, View, TextInput, Button, FlatList, StyleSheet, SafeAreaView, TouchableOpacity, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const sampleNotes = {
  Maths: [
    { id: '1', text: 'Pythagoras theorem: a² + b² = c²' },
    { id: '2', text: 'Area of circle = πr²' }
  ],
  Science: [
    { id: '1', text: 'Newton’s 1st Law: Inertia' },
    { id: '2', text: 'Photosynthesis: CO₂ + H₂O → O₂ + Glucose' }
  ]
};

const quizQuestions = {
  Maths: [
    { id: '1', question: 'What is 12 × 8?', answer: '96' },
    { id: '2', question: 'Square root of 81?', answer: '9' }
  ],
  Science: [
    { id: '1', question: 'What planet is known as the Red Planet?', answer: 'Mars' },
    { id: '2', question: 'H₂O is the chemical formula for?', answer: 'Water' }
  ]
};

function NotesScreen({ subject, subscribed }) {
  const [notes, setNotes] = useState(sampleNotes[subject] || []);
  const [text, setText] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>{subject} Notes</Text>
      <TextInput
        placeholder="Write a note..."
        value={text}
        onChangeText={setText}
        style={styles.input}
      />
      <Button
        title="Save Note"
        onPress={() => {
          if (text.trim()) {
            setNotes([{ id: Date.now().toString(), text }, ...notes]);
            setText('');
          }
        }}
      />
      <FlatList
        data={notes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <Text style={styles.item}>• {item.text}</Text>}
      />
      {!subscribed && (
        <View style={styles.adBanner}>
          <Text>[AD BANNER - Upgrade to remove ads]</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

function LockedScreen() {
  return (
    <View style={styles.container}>
      <Text style={{ fontSize: 18, textAlign: 'center' }}>
        This feature is for subscribers only.
      </Text>
      <Text style={{ marginTop: 10, textAlign: 'center' }}>Upgrade to unlock!</Text>
    </View>
  );
}

function QuizScreen({ subject }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const questionList = quizQuestions[subject] || [];
  const currentQ = questionList[currentIndex];

  if (!currentQ) {
    return (
      <View style={styles.container}>
        <Text>No quiz questions available.</Text>
      </View>
    );
  }

  const handleAnswer = () => {
    if (userAnswer.trim().toLowerCase() === currentQ.answer.toLowerCase()) {
      Alert.alert('✅ Correct!', `Answer: ${currentQ.answer}`);
    } else {
      Alert.alert('❌ Wrong', `Correct Answer: ${currentQ.answer}`);
    }
    setUserAnswer('');
    setCurrentIndex((prev) => (prev + 1) % questionList.length);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{subject} Quiz</Text>
      <Text style={{ fontSize: 18, marginBottom: 20 }}>{currentQ.question}</Text>
      <TextInput
        style={styles.input}
        placeholder="Type your answer here"
        value={userAnswer}
        onChangeText={setUserAnswer}
      />
      <TouchableOpacity style={styles.quizBtn} onPress={handleAnswer}>
        <Text style={{ color: '#fff' }}>Submit Answer</Text>
      </TouchableOpacity>
    </View>
  );
}

function SubjectTabs({ subject, subscribed }) {
  const Tab = createBottomTabNavigator();
  return (
    <Tab.Navigator>
      <Tab.Screen name="Notes">{() => <NotesScreen subject={subject} subscribed={subscribed} />}</Tab.Screen>
      <Tab.Screen name="Quiz">{() => subscribed ? <QuizScreen subject={subject} /> : <LockedScreen />}</Tab.Screen>
    </Tab.Navigator>
  );
}

const RootTab = createBottomTabNavigator();
export default function App() {
  const [subscribed, setSubscribed] = useState(false);

  return (
    <NavigationContainer>
      <RootTab.Navigator>
        <RootTab.Screen name="Maths">
          {() => <SubjectTabs subject="Maths" subscribed={subscribed} />}
        </RootTab.Screen>
        <RootTab.Screen name="Science">
          {() => <SubjectTabs subject="Science" subscribed={subscribed} />}
        </RootTab.Screen>
        <RootTab.Screen name="Upgrade">
          {() => (
            <View style={styles.container}>
              <Text style={styles.title}>Upgrade to Premium</Text>
              <Button title="Subscribe Now" onPress={() => setSubscribed(true)} />
            </View>
          )}
        </RootTab.Screen>
      </RootTab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 10, textAlign: 'center' },
  input: { borderWidth: 1, padding: 10, marginBottom: 10 },
  item: { padding: 10, borderBottomWidth: 1 },
  adBanner: { marginTop: 20, padding: 10, backgroundColor: '#ddd', alignItems: 'center' },
  quizBtn: { backgroundColor: 'blue', padding: 15, borderRadius: 10, alignItems: 'center' }
});
